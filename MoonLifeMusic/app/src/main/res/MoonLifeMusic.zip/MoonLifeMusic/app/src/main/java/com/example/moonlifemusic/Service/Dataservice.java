package com.example.moonlifemusic.Service;

import com.example.moonlife.Model.Album;
import com.example.moonlife.Model.Baihat;
import com.example.moonlife.Model.Listmucisc;
import com.example.moonlife.Model.QuangCao;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Dataservice {
    @GET("songbanner.php")
    Call<List<QuangCao>>  GetDataBanner();
    @GET("chude1.php")
    Call<List<Listmucisc>> GetDataChuDe1();
    @GET("chude2.php")
    Call<List<Listmucisc>> GetDataChuDe2();
    @GET("chude3.php")
    Call<List<Listmucisc>> GetDataChuDe3();
    @GET("Album.php")
    Call<List<Album>> GetDataAlbum();
    @GET("cothebanthich.php")
    Call<List<Baihat>> GetDataBaiHat();
    @GET("top100.php")
    Call<List<Listmucisc>> GetDataTop100();
    @GET("allAlbum.php")
    Call<List<Album>> GetDataallAlbum();
    @GET("bangxephang.php")
    Call<List<Baihat>> GetDataBangXepHang();
    @GET("bangxephangtop5.php")
    Call<List<Baihat>> GetDataBangXepHangtop5();



    @FormUrlEncoded
    @POST("danhsachbaihat.php")
    Call<List<Baihat>> GetDanhSachBaiHatPlayList(@Field("idplaylist") String idplaylist);
    @FormUrlEncoded
    @POST("timkiem.php")
    Call<List<Baihat>> GetTimKiem(@Field("key") String keywork);
    @FormUrlEncoded
    @POST("danhsachbaihatalbum.php")
    Call<List<Baihat>> GetDanhSachBaiHatAlbum(@Field("idalbum") String idalbum);
    @FormUrlEncoded
    @POST("danhsachcacplaylist.php")
    Call<List<Listmucisc>> GetDanhSachPlayList(@Field("idchude") String idchude);


}
